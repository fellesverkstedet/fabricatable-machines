# nodemcu-v3-fritzing
NodeMCU v3 Fritzing model

(based on https://github.com/squix78/esp8266-fritzing-parts/tree/master/nodemcu-v1.0)
